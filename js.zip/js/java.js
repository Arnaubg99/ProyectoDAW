function menu(callback) {
	var opcion = 'sdfgf';
  do {
  	opcion = prompt("Introduce un género: drama, comedia, terror");
  }
  while ((opcion !== 'drama') || (opcion !== 'comedia') || (opcion !== 'terror'));
  
  
 
  switch (opcion) {
    case 'drama':
      callback();
      break;
    case 'comedia':
      callback();
      break;
    case 'terror':
      callback();
      break;
    default:
      document.write("Introduce un género correcto");
  }
}

function peliculas(opcion){
	alert("Introduce 3 películas de dicho género");
  var arrayVacio = [];
  for (let i = 0; i < 3; i++){
  	
  }
  
}

menu(peliculas);

