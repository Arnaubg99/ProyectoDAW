window.onload = function(){
    swal('¡Bienvenido!','Antes de empezar te explicaré los controles.\nUtiliza las flechas del teclado para mover el personaje.\n· Boton arriba: Mover personaje arriba.\n· Boton abajo: Mover personaje abajo.\n· Boton derecha: Mover personaje derecha.\n· Boton izquierda: Mover personaje izquierda.\nPara cerrar los mensajes puedes utilizar la tecla "Enter" del teclado, la tecla "Espacio" del teclado o hacer clic en "Ok" con el ratón\nPara empezar a jugar muevete con el personaje hasta el botón "Start".\nPor cada reto completado se te sumarán 50 puntos.\nBuena Suerte.');
    var container = document.getElementById('container');
    var start = document.getElementById('start');
    var cliente1 = document.getElementById('cliente1');
    var indicador1 = document.getElementById('indicador1');
    var valla = document.getElementById('valla');
    var cliente2 = document.getElementById('cliente2');
    var indicador2 = document.getElementById('indicador2');
    var cuenta_atras = document.getElementById('cuenta_atras');
    var arbol = document.getElementById('arbol');
    var casa = document.getElementById('casa');
    var papa_noel = document.getElementById('papa_noel');
    var puerta = document.getElementById('puerta');
    var regalos = document.getElementById('regalos');
    var reno = document.getElementById('reno');
    var dueña = document.getElementById('dueña');
    var caja = document.getElementById('caja');
    var cereales = document.getElementById('cereales');
    var puesto_frutas_1 = document.getElementById('puesto_frutas_1');
    var puesto_frutas_2 = document.getElementById('puesto_frutas_2');
    var puesto_frutas_3 = document.getElementById('puesto_frutas_3');
    var puesto_frutas_4 = document.getElementById('puesto_frutas_4');
    var congelador = document.getElementById('congelador');
    var muro_comida = document.getElementById('muro_comida');
    var llave_id = document.getElementById('llave');
    var indicador3 = document.getElementById('indicador3');
    var boton = document.getElementById('boton');
            
    var puntos = 0;
    var start_on = false;
    var primera_charla = false;
    var platano = false;
    var platano_hecho = false;
    var cliente1_on = false;
    var naranjas = false;
    var naranjas_hecho = false;
    var cliente1_completado = false;
    var cliente2_on = false
    var cereales_on = false;
    var llave = false;
    var llave_cogida = false;
    var cliente2_completado = false;
    var cliente3 = false;
    var total = 0;
    var cliente2_error = false;
    var cambio_fondo = false;
    var papa_noel_on = false;
    var cambio_fondo2 = false;
    var detergente = false;
    var cambio_fondo3 = false;
    var papa_noel_completado = false;
    var juego_completado = false;

    var izquierda = 37;
    var arriba = 38;
    var derecha = 39;
    var abajo = 40;

    boton.onclick = function boton(){
        if(start_on == false){
            swal('¡Bienvenido!','Antes de empezar te explicaré los controles.\nUtiliza las flechas del teclado para mover el personaje.\n· Boton arriba: Mover personaje arriba.\n· Boton abajo: Mover personaje abajo.\n· Boton derecha: Mover personaje derecha.\n· Boton izquierda: Mover personaje izquierda.\nPara cerrar los mensajes puedes utilizar la tecla "Enter" del teclado, la tecla "Espacio" del teclado o hacer clic en "Ok" con el ratón\nPara empezar a jugar muevete con el personaje hasta el botón "Start".\nPor cada reto completado se te sumarán 50 puntos.\nBuena Suerte.')
        }
        else if(start_on == true && primera_charla == false){
            swal('¡A jugar!','Como te habrás fijado estas en un mercado gigante.\nTendrás ayudar a la dueña(Rosa) a dar los productos indicados a los clientes.\nElla te dará tu recompensa.\nHablá con ella y presentate.');
        }
        else if(primera_charla == true && platano == false){
            swal('¡Muy Buenas!','Rosa: Encantada, soy la dueña de este mercado.\nMenos mal que has venido a ayudarme, yo sola no puedo atender a todos los clientes.\nNecesitaré que entregues el producto que desea cada cliente.\nVamos a hacer una prueba, traeme un plátano del puesto de frutas.');
        }
        else if(platano == true && platano_hecho == false){
            swal('¡Has cogido un plátano!','Llevaselo a Rosa');
        }
        else if(platano_hecho == true && cliente1_on == false){
            swal('¡Muy bien hecho!','Rosa: Ahora ve a hablar con el cliente 1 a ver que producto quiere.\nSe te han sumado 50 puntos.','success');
        }
        else if(cliente1_on == true && naranjas == false){
            swal('¡Hola, que tal!','Cliente 1: Yo soy Ramón, y habia venido al mercado porque necesito 1kg de naranjas.\n¿Podrias ayudarme?');
        }
        else if(naranjas == true && naranjas_hecho == false){
            swal('¡Has cogido 1kg de naranjas','Lleva el producto al cliente');
        }
        else if(naranjas_hecho == true && cliente1_completado == false && cliente1.style.visibility != "hidden"){
            swal('¡Muchas gracias!','Cliente 1: Ahora ya podré hacerme mis zumos.\nNos vemos.');
        }
        else if(naranjas_hecho == true && cliente1_completado == false && cliente1.style.visibility == "hidden"){
            swal('¡Cliente 1 completado!','Ve a hablar con Rosa.','success');
        }
        else if(cliente1_completado == true && cliente2_on == false){
            swal('¡Lo has logrado!','Rosa: Lo estas haciendo muy bien, pero veamos si es suficiente.\nBusca al cliente 2 a ver que desea.\nSe han sumado 50 puntos.');
        }
        else if(cliente2_on == true && cereales_on == false){
            swal('¡Hola!','Cliente 2: ¿Has visto que buena pinta tienen estos canelones?\nMadre mia se me cae la baba, pero tengo que concentrarme que he venido a comprar otras cosa.\nUy perdona, no me he presentado. Y soy Andrea, mi madre me ha mandado al mercado a comprar cereales.\nCreo que eran unos con caja verde.\nAyudame a encontrarlos, por favor.');
        }
        else if(cereales_on == true && llave == false && llave_id.style.visibility != "visible"){
            swal('¡Has cogido una caja de cereales!','Lleva el producto al cliente 2');
        }
        else if(cereales_on == true && llave == false && llave_id.style.visibility == "visible"){
            swal('¡Oh no!','Ha aparecido un portón y no podemos darle el producto al cliente.\nHabla con Rosa a ver que podemos hacer.','warning');
        }
        else if(llave == true && llave_cogida == false && cliente2_error == false){
            swal('Que???','Rosa: Esto si que no me lo esperaba, hacia mucho tiempo que no aparecia el portón.\nTengo una llave, pero no se donde la habré dejado.\nAyudame a buscarla rápido, solo tenemos 30 segundos antes que el cliente se asuste y se marche.');
        }
        else if(llave == true && llave_cogida == false && cliente2_error == true && cliente2_completado == false && cliente3 == false){
            swal('¡Has fallado!','No lo has logrado y el cliente se ha marchado.\nVes a hablar con Rosa.');
        }
        else if(llave == true && llave_cogida == true && cliente2_error == false && cliente2_completado == false && cliente3 == false){
            swal('¡Has encontrado la llave!','Lleva el producto al cliente');
        }
        else if(llave == true && llave_cogida == true && cliente2_error == true && cliente2_completado == false && cliente3 == false){
            swal('¡Has encontrado la llave!','Pero es demsiado tarde, el cliente ya se ha ido.\nVes a hablar con Rosa.');
        }
        else if(cliente2_error == false && llave_cogida == true && cliente2_completado == true && cliente2.style.visibility != "hidden" && cliente3 == false){
            swal('¡Menos mal!','Cliente 2: Has podido abrir el portón, estaba muy asustada.\nMuchas gracias por los cereales.\nQue vaya bien.');
        }
        else if(cliente2_error == false && llave_cogida == true && cliente2_completado == true && cliente2.style.visibility == "hidden" && cliente3 == false){
            swal('¡Cliente 2 completado!','Ve a hablar con Rosa.','success');
        }
        else if(cliente2_completado == true && cliente2_error == false && cliente3 == true && papa_noel_on == false){
            swal('¡Lo has logrado!','Rosa: Lo estas haciendo muy bien, pero veamos si es suficiente.\nBusca al cliente 3, no lo veo por aquí, a ver que desea.\nSe han sumado 50 puntos.');
        }
        else if(cliente2_error == true && cliente3 == true && papa_noel_on == false){
            swal('¡Oh no!','Rosa: El cliente 2 se ha ido, no podré recompensarte por esto.\nIntenta que no vuelva a suceder.\nBusca al cliente 3, no lo veo por aquí, a ver que desea.');
        }
        else if(cambio_fondo == true && papa_noel_on == true && detergente == false){
            swal('¡Hola!','Papa Noel: Encantado de conocerte.\nBienvenido a Rovaniemi, Finlandia.\nImagino que te ha enviado Rosa. Habia ido a la tienda a por detergente, pero he visto que había personas esperando asi que le he dicho a Rosa que me lo traiga.\nPodrías ir a buscarlos por mi?\nSi no me equivoco la caja era de color roja.');
        }
        else if(cambio_fondo2 == true && detergente == true && papa_noel_completado == false){
            swal('¡Has cogido una caja de detergente!','Llevasela a Papa Noel');
        }
        else if(papa_noel_completado == true && juego_completado == false){
            swal('¡Cliente 3 completado!','Ve a hablar con Rosa.','success');
        }
        else if(juego_completado == true){
            swal('¡Lo has logrado!','Rosa: Te agradezco que me hayas ayudado, sin ti no hubiese sido posible.\nHasta la próxima.\nSe han sumado 50 puntos.');
        }
    }
    
    document.getElementById('puntuacion').innerHTML = total;

    document.addEventListener('keydown', function(key){
        var personaje_id = document.getElementById('personaje');
        var personaje_style = window.getComputedStyle(personaje_id);
        var personaje_horizontal = personaje_style.getPropertyValue('right');
        var personaje_vertical = personaje_style.getPropertyValue('bottom');

        var horizontal = parseInt(personaje_horizontal);
        var vertical = parseInt(personaje_vertical);

        if(key.keyCode == izquierda){
            personaje_id.style.backgroundPosition = "-45px -113px";
            if(horizontal == 380){
                personaje_id.style.right = horizontal + "px"; //COLISION FINAL IZQUIERDA
            }
            else if(horizontal == 260 && vertical > 150 && puesto_frutas_1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION FRUTAS
            }
            else if(horizontal == 340 && vertical > 320 && cliente1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CLIENTE 1
            }
            else if(horizontal == 120 && vertical < 120 && congelador.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CONGELADOR
            }
            else if(horizontal == 140 && vertical <= 180 && vertical >= 130 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 150 && vertical <= 200 && vertical >= 180 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 160 && vertical <= 230 && vertical >= 210 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 170 && vertical <= 260 && vertical >= 240 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 180 && vertical <= 290 && vertical >= 270 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 330 && vertical == 60 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(horizontal == 250 && vertical <= 60 && vertical >= 30 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(horizontal == 270 && vertical == 20 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(horizontal == 260 && vertical > 310 && vertical < 350 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 270 && vertical == 350 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 280 && vertical > 350 && vertical < 370 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 290 && vertical == 370 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 110 && vertical == 290 && papa_noel.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION PAPA NOEL
            }
            else{
                personaje_id.style.right = (horizontal + 10) + "px";
            }
        }
        else if(key.keyCode == arriba){
            personaje_id.style.backgroundPosition = "-45px -42px";
            if(vertical == 370){
                personaje_id.style.bottom = vertical + "px"; //COLISION FINAL ARRIBA
            }
            else if(vertical == 270 && horizontal < 120 && caja.style.visibility != "hidden"){ //COLISION CAJA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 330 && horizontal < 150 && cereales.style.visibility != "hidden"){ //COLISION CEREALES
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 150 && horizontal < 320 && horizontal > 260 && puesto_frutas_1.style.visibility != "hidden"){ //COLISION FRUTAS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 320 && horizontal > 340 && horizontal < 380 && cliente1.style.visibility != "hidden"){ //COLISION CLIENTE 1
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 70 && horizontal > 120 && horizontal < 330 && muro_comida.style.visibility != "hidden"){ //COLISION MURO COMIDA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 120 && horizontal > 140 && horizontal < 260 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 20 && horizontal <= 270 && horizontal >= 260 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 10 && horizontal <= 360 && horizontal >= 280 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 310 && horizontal <= 340 && horizontal >= 270 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 270 && horizontal < 100 && casa.style.visibility == "visible"){ //COLISION CASA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 290 && horizontal < 120 && casa.style.visibility == "visible"){ //COLISION CASA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 280 && horizontal < 160 && horizontal >= 120 && papa_noel.style.visibility == "visible"){ //COLISION PAPA NOEL
                personaje_id.style.bottom = vertical + "px";
            }
            else{
                personaje_id.style.bottom = (vertical + 10) + "px";
            }
        }
        else if(key.keyCode == derecha){
            personaje_id.style.backgroundPosition = "-45px";
            if(horizontal == 0){
                personaje_id.style.right = horizontal + "px"; //COLISION FINAL DERECHA
            }
            else if(horizontal == 120 && vertical > 270 && caja.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CAJA
            }
            else if(horizontal == 150 && vertical > 330 && cereales.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CEREALES
            }
            else if(horizontal == 320 && vertical > 150 && puesto_frutas_1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION FRUTAS
            }
            else if(horizontal == 380 && vertical > 320 && cliente1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CLIENTE 1
            }
            else if(horizontal == 330 && vertical > 70 && vertical < 120 && muro_comida.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION MURO COMIDA
            }
            else if(horizontal == 190 && vertical < 80 && cliente2.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CLIENTE 2
            }
            else if(horizontal == 160 && vertical < 80 && congelador.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CONGELADOR
            }
            else if(horizontal == 260 && vertical > 120 && vertical <= 160 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 250 && vertical > 160 && vertical < 200 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 240 && vertical >= 200 && vertical < 230 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 230 && vertical >= 230 && vertical < 260 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 220 && vertical >= 260 && vertical < 280 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 210 && vertical >= 280 && vertical < 300 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(vertical < 70 && vertical >= 20 && horizontal == 370 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(vertical == 60 && horizontal == 290 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(vertical >= 320 && vertical <= 350 && horizontal == 350 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(vertical > 350 && vertical < 370 && horizontal == 340 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(vertical == 370 && horizontal == 330 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(vertical > 350 && vertical == 370 && horizontal == 330 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION CASA
            }
            else if(horizontal == 100 && vertical > 320 && casa.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION CASA
            }
            else if(horizontal == 100 && (vertical == 290 || vertical == 280) && casa.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION CASA
            }
            else if(horizontal == 160 && vertical > 280 && vertical < 320 && papa_noel.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION PAPA NOEL
            }
            else if(horizontal == 150 && vertical >= 320 && vertical < 350 && papa_noel.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION PAPA NOEL
            }
            else{
                personaje_id.style.right = (horizontal - 10) + "px";
            }
        }
        else if(key.keyCode == abajo){
            personaje_id.style.backgroundPosition = "-45px -5px";
            if(vertical == 0){
                personaje_id.style.bottom = vertical + "px"; //COLISION FINAL ABAJO
            }
            else if(vertical == 120 && horizontal < 330 && horizontal > 120 && muro_comida.style.visibility != "hidden"){
                personaje_id.style.bottom = vertical + "px"; //COLISION MURO COMIDA
            }
            else if(vertical == 80 && horizontal > 150 && valla.style.visibility == "visible"){
                personaje_id.style.bottom = vertical + "px"; //COLISION VALLA
            }
            else if(vertical == 300 && horizontal > 180 && horizontal < 210 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 280 && horizontal == 210 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 260 && horizontal == 220 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 230 && horizontal == 230 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 200 && horizontal == 240 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 170 && horizontal == 250 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 270 && horizontal == 180 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 240 && horizontal == 170 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 210 && horizontal == 160 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 190 && horizontal == 150 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 70 && horizontal <= 360 && horizontal > 330 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 60 && horizontal <= 330 && horizontal > 280 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 70 && horizontal <= 280 && horizontal > 250 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 360 && horizontal == 280 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 350 && horizontal == 270 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 370 && horizontal == 290 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 370 && horizontal == 330 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 360 && horizontal == 340 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 350 && horizontal <= 140 && papa_noel.style.visibility == "visible"){ //COLISION PAPA NOEL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 320 && horizontal == 150 && papa_noel.style.visibility == "visible"){ //COLISION PAPA NOEL
                personaje_id.style.bottom = vertical + "px";
            }
            else{
                personaje_id.style.bottom = (vertical - 10) + "px";
            }
        }
        if(vertical <= 200 && vertical > 180 && horizontal >= 180 && horizontal <= 200 && start_on == false){
            swal('¡A jugar!','Como te habrás fijado estas en un mercado gigante.\nTendrás ayudar a la dueña(Rosa) a dar los productos indicados a los clientes.\nElla te dará tu recompensa.\nHablá con ella y presentate.');
            start.style.visibility = "hidden";
            start_on = true;
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && start_on == true && primera_charla == false){
            swal('¡Muy Buenas!','Rosa: Encantada, soy la dueña de este mercado.\nMenos mal que has venido a ayudarme, yo sola no puedo atender a todos los clientes.\nNecesitaré que entregues el producto que desea cada cliente.\nVamos a hacer una prueba, traeme un plátano del puesto de frutas.');
            primera_charla = true;
        }
        else if(vertical == 310 && horizontal == 320 && primera_charla == true && platano == false){
            swal('¡Has cogido un plátano!','Llevaselo a Rosa');
            platano = true;
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && platano == true && platano_hecho == false){
            swal('¡Muy bien hecho!','Rosa: Ahora ve a hablar con el cliente 1 a ver que producto quiere.\nSe te han sumado 50 puntos.','success');
            platano_hecho = true;
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
        }
        else if(vertical == 320 && horizontal == 360 && platano_hecho == true && cliente1_on == false){
            swal('¡Hola, que tal!','Cliente 1: Yo soy Ramón, y habia venido al mercado porque necesito 1kg de naranjas.\n¿Podrias ayudarme?');
            cliente1_on = true;
        }
        else if(horizontal == 260 && (vertical == 190 || vertical == 200) && cliente1_on == true && naranjas == false){
            swal('¡Has cogido 1kg de naranjas','Lleva el producto al cliente');
            naranjas = true;
        }
        else if(vertical == 320 && horizontal == 360 && naranjas == true && naranjas_hecho == false){
            naranjas_hecho = true;
            swal('¡Muchas gracias!','Cliente 1: Ahora ya podré hacerme mis zumos.\nNos vemos.');
            setTimeout(completado,4000);
            function completado(){
                swal('¡Cliente 1 completado!','Ve a hablar con Rosa.','success');
                cliente1.style.visibility = "hidden";
                indicador1.style.visibility = "hidden";
            }
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && naranjas_hecho == true && cliente1_completado == false){
            swal('¡Lo has logrado!','Rosa: Lo estas haciendo muy bien, pero veamos si es suficiente.\nBusca al cliente 2 a ver que desea.\nSe han sumado 50 puntos.');
            cliente1_completado = true;
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
        }
        else if(vertical >= 0 && vertical <= 20 && horizontal == 190 && cliente1_completado == true && cliente2_on == false){
            swal('¡Hola!','Cliente 2: ¿Has visto que buena pinta tienen estos canelones?\nMadre mia se me cae la baba, pero tengo que concentrarme que he venido a comprar otras cosa.\nUy perdona, no me he presentado. Y soy Andrea, mi madre me ha mandado al mercado a comprar cereales.\nCreo que eran unos con caja verde.\nAyudame a encontrarlos, por favor.');
            cliente2_on = true;
        }
        else if(vertical > 340 && horizontal == 150 && cliente2_on == true && cereales_on == false){
            swal('¡Has cogido una caja de cereales!','Lleva el producto al cliente 2');
            cereales_on = true;
            valla.style.visibility = "visible";
            setTimeout(valla_on,6000);
            function valla_on(){
                swal('¡Oh no!','Ha aparecido un portón y no podemos darle el producto al cliente.\nHabla con Rosa a ver que podemos hacer.','warning');
                setTimeout(llave,2000);
                function llave(){
                    llave_id.style.visibility = "visible";
                }
            }
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && cereales_on == true && llave == false){
            swal('Que???','Rosa: Esto si que no me lo esperaba, hacia mucho tiempo que no aparecia el portón.\nTengo una llave, pero no se donde la habré dejado.\nAyudame a buscarla rápido, solo tenemos 30 segundos antes que el cliente se asuste y se marche.');
            llave = true;
            var total = 5;
            var interval = setInterval(contador,1000);
            function contador() {
                document.getElementById('cuenta_atras').innerHTML = total;
                if(total==0){
                    cliente2.style.visibility = "hidden";
                    indicador2.style.visibility = "hidden";
                    cuenta_atras.style.visibility = "hidden";
                    clearInterval(interval);
                    cliente2_error = true;
                    setTimeout(mensaje,2000);
                    function mensaje(){
                        swal('¡Has fallado!','No lo has logrado y el cliente se ha marchado.\nVes a hablar con Rosa.');
                    }
                }
                else if(llave_cogida == true){
                    clearInterval(interval);
                    cuenta_atras.style.visibility = "hidden";
                }
                else{
                    total-=1;
                }
            }
        }
        else if(horizontal == 170 && vertical == 120 && llave == true && llave_cogida == false && llave_id.style.visibility != "hidden"){
            if(cliente2_error == false){
                swal('¡Has encontrado la llave!','Lleva el producto al cliente');
            }
            else{
                swal('¡Has encontrado la llave!','Pero es demsiado tarde, el cliente ya se ha ido.\nVes a hablar con Rosa.');
            }
            llave_cogida = true;
            llave_id.style.visibility = "hidden";
            valla.style.visibility = "hidden";
        }
        else if(vertical >= 0 && vertical <= 20 && horizontal == 190 && cliente2_error == false && llave_cogida == true && cliente2_completado == false){
            swal('¡Menos mal!','Cliente 2: Has podido abrir el portón, estaba muy asustada.\nMuchas gracias por los cereales.\nQue vaya bien.');
            cliente2_completado = true;
            setTimeout(mensaje2,5000);
            function mensaje2(){
                swal('¡Cliente 2 completado!','Ve a hablar con Rosa.','success');
                cliente2.style.visibility = "hidden";
                indicador2.style.visibility = "hidden";
            }
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && cliente2_completado == true && cliente2_error == false && cliente3 == false){
            swal('¡Lo has logrado!','Rosa: Lo estas haciendo muy bien, pero veamos si es suficiente.\nBusca al cliente 3, no lo veo por aquí, a ver que desea.\nSe han sumado 50 puntos.');
            cliente3 = true;
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && cliente2_error == true && cliente3 == false){
            swal('¡Oh no!','Rosa: El cliente 2 se ha ido, no podré recompensarte por esto.\nIntenta que no vuelva a suceder.\nBusca al cliente 3, no lo veo por aquí, a ver que desea.');
            cliente3 = true;
            llave_id.style.visibility = "hidden";
        }
        else if((vertical == 0 || vertical == 10) && horizontal == 0 && cliente3 == true && cambio_fondo == false){
            cambio_fondo = true;
            indicador3.style.visibility = "visible";
            arbol.style.visibility = "visible";
            casa.style.visibility = "visible";
            papa_noel.style.visibility = "visible";
            puerta.style.visibility = "visible";
            regalos.style.visibility = "visible";
            reno.style.visibility = "visible";
            dueña.style.visibility = "hidden";
            caja.style.visibility = "hidden";
            cereales.style.visibility = "hidden";
            puesto_frutas_1.style.visibility = "hidden";
            puesto_frutas_2.style.visibility = "hidden";
            puesto_frutas_3.style.visibility = "hidden";
            puesto_frutas_4.style.visibility = "hidden";
            congelador.style.visibility = "hidden";
            muro_comida.style.visibility = "hidden";
            valla.style.visibility = "hidden";
            llave_id.style.visibility = "hidden";
            container.style.backgroundImage = "url('images/fondo_nieve.jpg')";
        }
        else if(vertical == 280 && horizontal < 150 && horizontal >= 120 && cambio_fondo == true && papa_noel_on == false){
            swal('¡Hola!','Papa Noel: Encantado de conocerte.\nBienvenido a Rovaniemi, Finlandia.\nImagino que te ha enviado Rosa. Habia ido a la tienda a por detergente, pero he visto que había personas esperando asi que le he dicho a Rosa que me lo traiga.\nPodrías ir a buscarlos por mi?\nSi no me equivoco la caja era de color roja.');
            papa_noel_on = true;
        }
        else if((vertical == 0 || vertical == 10) && horizontal == 0 && papa_noel_on == true && cambio_fondo2 == false){
            cambio_fondo2 = true;
            indicador3.style.visibility = "hidden";
            arbol.style.visibility = "hidden";
            casa.style.visibility = "hidden";
            papa_noel.style.visibility = "hidden";
            regalos.style.visibility = "hidden";
            reno.style.visibility = "hidden";
            dueña.style.visibility = "visible";
            caja.style.visibility = "visible";
            cereales.style.visibility = "visible";
            puesto_frutas_1.style.visibility = "visible";
            puesto_frutas_2.style.visibility = "visible";
            puesto_frutas_3.style.visibility = "visible";
            puesto_frutas_4.style.visibility = "visible";
            congelador.style.visibility = "visible";
            muro_comida.style.visibility = "visible";
            container.style.backgroundImage = "url('images/fondo.jpg')";
        }
        else if(vertical == 120 && horizontal < 320 && horizontal >= 260 && cambio_fondo2 == true && detergente == false){
            swal('¡Has cogido una caja de detergente!','Llevasela a Papa Noel');
            detergente = true;
        }
        else if((vertical == 0 || vertical == 10) && horizontal == 0 && detergente == true && cambio_fondo3 == false){
            cambio_fondo3 = true;
            indicador3.style.visibility = "visible";
            arbol.style.visibility = "visible";
            casa.style.visibility = "visible";
            papa_noel.style.visibility = "visible";
            puerta.style.visibility = "visible";
            regalos.style.visibility = "visible";
            reno.style.visibility = "visible";
            dueña.style.visibility = "hidden";
            caja.style.visibility = "hidden";
            cereales.style.visibility = "hidden";
            puesto_frutas_1.style.visibility = "hidden";
            puesto_frutas_2.style.visibility = "hidden";
            puesto_frutas_3.style.visibility = "hidden";
            puesto_frutas_4.style.visibility = "hidden";
            congelador.style.visibility = "hidden";
            muro_comida.style.visibility = "hidden";
            valla.style.visibility = "hidden";
            llave_id.style.visibility = "hidden";
            container.style.backgroundImage = "url('images/fondo_nieve.jpg')";
        }
        else if(vertical == 280 && horizontal < 150 && horizontal >= 120 && cambio_fondo3 == true && papa_noel_completado == false){
            swal('¡Has llegado!','Papa Noel: Muchas gracias por ayudarme. Estas navidades seré bueno contigo.\nHO HO HO FELIZ NAVIDAD');
            setTimeout(cambio,3000);
            function cambio(){
                papa_noel_completado = true;
                indicador3.style.visibility = "hidden";
                arbol.style.visibility = "hidden";
                casa.style.visibility = "hidden";
                papa_noel.style.visibility = "hidden";
                regalos.style.visibility = "hidden";
                reno.style.visibility = "hidden";
                dueña.style.visibility = "visible";
                caja.style.visibility = "visible";
                cereales.style.visibility = "visible";
                puesto_frutas_1.style.visibility = "visible";
                puesto_frutas_2.style.visibility = "visible";
                puesto_frutas_3.style.visibility = "visible";
                puesto_frutas_4.style.visibility = "visible";
                congelador.style.visibility = "visible";
                muro_comida.style.visibility = "visible";
                container.style.backgroundImage = "url('images/fondo.jpg')";
                setTimeout(papanoel,3000);
                function papanoel(){
                    swal('¡Cliente 3 completado!','Ve a hablar con Rosa.','success');
                }
            }
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && papa_noel_completado == true && juego_completado == false){
            swal('¡Lo has logrado!','Rosa: Te agradezco que me hayas ayudado, sin ti no hubiese sido posible.\nHasta la próxima.\nSe han sumado 50 puntos.');
            juego_completado = true;
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
        }
        else if(juego_completado == true){
            setTimeout(final,4000);
            function final(){
                indicador3.style.visibility = "hidden";
                arbol.style.visibility = "hidden";
                casa.style.visibility = "hidden";
                papa_noel.style.visibility = "hidden";
                regalos.style.visibility = "hidden";
                reno.style.visibility = "hidden";
                dueña.style.visibility = "hidden";
                caja.style.visibility = "hidden";
                cereales.style.visibility = "hidden";
                puesto_frutas_1.style.visibility = "hidden";
                puesto_frutas_2.style.visibility = "hidden";
                puesto_frutas_3.style.visibility = "hidden";
                puesto_frutas_4.style.visibility = "hidden";
                congelador.style.visibility = "hidden";
                muro_comida.style.visibility = "hidden";
                personaje_id.style.visibility = "hidden";
                puerta.style.visibility = "hidden";
                boton.style.visibility = "hidden";
                container.style.backgroundImage = "url('images/fondo_final.png')";
            }
        }
    });
}