window.onload = function(){

    var game_start = false;
    
        /* codigo inutil

        var url_img_left1 = "url(./game_images/pjs_character_sheet_nbg.png) -81px -187px";
        var url_img_left2 = "url(./game_images/pjs_character_sheet_nbg.png) -107px -186px";
        var url_img_left3 = "url(./game_images/pjs_character_sheet_nbg.png) -132px -186px";

        var url_img_right1 = "url(./game_images/pjs_character_sheet_nbg.png) -80px -223px";
        var url_img_right2 = "url(./game_images/pjs_character_sheet_nbg.png) -106px -222px";
        var url_img_right3 = "url(./game_images/pjs_character_sheet_nbg.png) -132px -223px";

        var url_img_back1 = "url(./game_images/pjs_character_sheet_nbg.png) -80px -259px";
        var url_img_back2 = "url(./game_images/pjs_character_sheet_nbg.png) -107px -259px";
        var url_img_back3 = "url(./game_images/pjs_character_sheet_nbg.png) -133px -259px";


        var url_img_front = [
            "url('./game_images/pjs_character_sheet_nbg.png') -81px -151px",
            "url('./game_images/pjs_character_sheet_nbg.png') -107px -151px",
            "url('./game_images/pjs_character_sheet_nbg.png') -132px -151px"
        ];

        var count = 0;

        function change_front_img(array_count){
            
            if (count == 0){
                pj.style.background = array_count[count];
                count++;
                console.log(pj.style.background);
            }
            if (count = 1){
                pj.style.background = array_count[count];
                count++;
                console.log(pj.style.background);
            }
            if (count = 2){
                pj.style.background = array_count[count];
                count = 0;
                console.log(pj.style.background);
            }
            count++;
            if(count = 3){
                count = 0;
            }
            console.log(count);
            }
        
            setInterval(change_front_img(url_img_front), 1000);
        

        
        CONSULTAR APPENDCHILD, REMOVECHILD, CREATEELEMENT(NOMBRETAG) 
        */

    //------------------CREATE NPC----------------------------------

    function create_npc(npc_num, x, y){
        console.log(score);
        var npc = document.createElement("div");
        document.getElementById("game_area").appendChild(npc);
        npc.setAttribute("id", "npc"+npc_num);
        npc.setAttribute("class", "npc");
        npc.style.left = x;
        npc.style.top = y;
        npc.style.width = "18px";
        npc.style.height = "29px";
        npc.style.display = "block";
        npc.style.position = "absolute";
        var npc_background = "";
        random_npc_look = (Math.round(Math.random() * 3)); //Num random de 0 a 3
            if (random_npc_look == 0){
                npc_background = "url('./game_images/pjs_character_sheet_nbg.png') -161px -151px";
            } else if (random_npc_look == 1){
                npc_background = "url('./game_images/pjs_character_sheet_nbg.png') -239px -7px";
            } else if (random_npc_look ==2){
                npc_background = "url('./game_images/pjs_character_sheet_nbg.png') -5px -151px";
            } else if (random_npc_look == 3){
                npc_background = "url('./game_images/pjs_character_sheet_nbg.png') -237px -151px";
            }
        npc.style.background = npc_background;
        
    }

    //---------------------------------------------------------

    //----------------------REMOVE NPC----------------------------
    function npc_removal(npc_to_remove){
    var remove_npc = document.getElementById(npc_to_remove);
    remove_npc.parentElement.removeChild(remove_npc);
    }
    //------------------------------------------------------------

    //---------------------MODAL-------------------------------

    var modal = document.getElementById("modal1");
    var btn = document.getElementById("modal_button");
    var span = document.getElementsByClassName("modal_close")[0];

    btn.onclick = function() {
        modal.style.display = "block";
    }

    span.onclick = function() {
        modal.style.display = "none";
        game_start = true;
        timer();
        main_game();
    }

    //-------------------------------------------------------------

    //--------------------------Temporitzador----------------------------
    function timer(){
        if (game_start == true){
            function startTimer(duration, display) {
                var timer = duration, minutes, seconds;
                setInterval(function () {
                    minutes = parseInt(timer / 60, 10);
                    seconds = parseInt(timer % 60, 10);

                    minutes = minutes < 10 ? "0" + minutes : minutes;
                    seconds = seconds < 10 ? "0" + seconds : seconds;

                    display.textContent = "Temps: " + minutes + ":" + seconds;

                    if (--timer < 0) {
                        display.textContent = "Fi del joc";
                        game_start = false;
                        document.getElementById("modal2").style.display = "block";
                    }
                }, 1000);
            }
        }

        var threeMinutes = 60 * 3;
        display = document.getElementById("timer_p");
        startTimer(threeMinutes, display);
    }

    //-------------------------------------------------------------------




    //---------------------------JOC----------------------------------

    function main_game(){
    
        var pj = document.getElementById("pj");
        var game_area = document.getElementById("game_area");
        var cargo_request = document.getElementById("cargo_request");
        var cargo_area = document.getElementById("cargo_area");
        var score = 0;
        document.getElementById("score").innerHTML = score;
        document.getElementById("final_score").innerHTML = score;
        var score_up = 10;
        var speed = 5;
        var arrow_left = 37; // 37 = codi de la tecla fletxa esquerra del teclat
        var arrow_right = 39;
        var arrow_top = 38;
        var arrow_bottom = 40;
        var random_delivery = 0;
        var random_obj = 0;
        var url_obj = "";
        var cargo_check = false;
        
        cargo_request.style.display = "none";

        var request_array = [
            document.getElementById('request1'),
            document.getElementById('request2'),
            document.getElementById('request3'),
            document.getElementById('request4'),
        ];
        var delivery_area_array = [
            document.getElementById('delivery_area1'),
            document.getElementById('delivery_area2'),
            document.getElementById('delivery_area3'),
            document.getElementById('delivery_area4'),
        ];



        //Peticions a entregar------------------------------------------------------
        function ronda_entrega(){

            cargo_request.style.display = "block";
            random_delivery = (Math.round(Math.random() * 3)); //Num random de 0 a 3
            random_obj = (Math.round(Math.random() * 3));
            
            if (random_obj == 0){
                url_obj = "url('./game_images/fruits.png')";
            } else if (random_obj == 1){
                url_obj = "url('./game_images/meat.png')";
            } else if (random_obj ==2){
                url_obj = "url('./game_images/bakery.png')";
            } else if (random_obj == 3){
                url_obj = "url('./game_images/fish.png')";
            }

            cargo_request.style.background = url_obj; //Mostrar en el camio la imatge a entregar

            //Mostrar productes i activar area de la casa
            request_array[random_delivery].style.background = url_obj;
            request_array[random_delivery].style.display = "block";
            delivery_area_array[random_delivery].style.display ="block";
            cargo_area.style.display = "block";
                                            
            if (score == 10){
                create_npc(1, "200px", "500px");
                create_npc(5, "510px", "380px");
                create_npc(6, "490px", "380px");
                create_npc(7, "470px", "380px");
                
            }
            if (score == 20){
                npc_removal("npc1");
                npc_removal("npc5");
                npc_removal("npc6");
                npc_removal("npc7");
                create_npc(2, "430px", "160px");
                create_npc(3, "50px", "210px");
                create_npc(4, "350px", "300px");
            }
            if (score == 50){
                npc_removal("npc3");
                npc_removal("npc4");
                
            }
            if (score == 70){
                create_npc(1, "200px", "500px");
                create_npc(3, "50px", "210px");
                create_npc(4, "350px", "300px");
            }
            if (score == 90){
                create_npc(5, "510px", "380px");
                create_npc(6, "490px", "380px");
                create_npc(7, "470px", "380px");
            }
            if (score == 110){
                npc_removal("npc5");
                npc_removal("npc6");
                create_npc(8, "460px", "515px");
                create_npc(9, "460px", "485px");
            }

        }
        //Fi peticions a entregar--------------------------------------------------


        document.addEventListener('keydown', function(key){ //Funció per determinar el moviment del div "pj"
            //Algorisme per agafar els valors de tamany de l'estil associat al div "pj" i convertir-lo en int
            if (game_start == true){
                var pj_left_string = window.getComputedStyle(pj, null).getPropertyValue('left');
                var pj_left_int = parseInt(pj_left_string);

                var pj_top_string = window.getComputedStyle(pj, null).getPropertyValue('top');
                var pj_top_int = parseInt(pj_top_string);

                var pj_width_string = window.getComputedStyle(pj, null).getPropertyValue('width');
                var pj_width_int = parseInt(pj_width_string);

                var pj_height_string = window.getComputedStyle(pj, null).getPropertyValue('height');
                var pj_height_int = parseInt(pj_height_string);
                //-------------------------------------------------------------------------------------------------------------

                //Algorisme per agafar els valors de tamany de l'estil associat al div "game_area" i convertir-lo en int
                var game_area_left_string = window.getComputedStyle(game_area, null).getPropertyValue('left');
                var game_area_left_int = parseInt(game_area_left_string);

                var game_area_top_string = window.getComputedStyle(game_area, null).getPropertyValue('top');
                var game_area_top_int = parseInt(game_area_top_string);

                var game_area_width_string = window.getComputedStyle(game_area, null).getPropertyValue('width');
                var game_area_width_int = parseInt(game_area_width_string);

                var game_area_height_string = window.getComputedStyle(game_area, null).getPropertyValue('height');
                var game_area_height_int = parseInt(game_area_height_string);
                //-------------------------------------------------------------------------------------------------------------
            
                var speedx = 0;
                var speedy = 0;

                //Controlar moviment + colisions amb els marges de la pantalla-------------------------------------------
                if (pj_left_int - speed < game_area_left_int && key.keyCode == arrow_left) { //fletxa esquerra
                    pj_left_int = 0;
                } else if (key.keyCode == arrow_left) {
                    speedx = speedx - speed;
                }   

                if (pj_left_int + pj_width_int + speed > game_area_left_int + game_area_width_int && key.keyCode == arrow_right){ //fletxa dreta
                    pj_left_int = game_area_left_int + game_area_width_int - pj_width_int;
                } else if (key.keyCode == arrow_right){
                    speedx = speedx + speed;
                }

                if (pj_top_int - speed < game_area_top_int && key.keyCode == arrow_top){ //fletxa amunt
                    pj_top_int = 0;
                }else if (key.keyCode == arrow_top) {
                    speedy = speedy - speed;
                }

                if (pj_top_int + pj_height_int + speed > game_area_top_int + game_area_height_int && key.keyCode == arrow_bottom){ //fletxa avall
                    pj_top_int = game_area_top_int + game_area_height_int - pj_height_int;
                }else if (key.keyCode == arrow_bottom){
                    speedy = speedy + speed;
                }
                //Fi colisio amb marges de la pantalla -----------------------------------------------------------------

                //Controlar entrada area carrega ----------------------------------------
                if (cargo_check == false){
                        var cargo_area_left_string = window.getComputedStyle(cargo_area, null).getPropertyValue('left');
                        var cargo_area_left_int = parseInt(cargo_area_left_string); //Marge esquerre de l'objecte (int)
                        var cargo_area_width_string = window.getComputedStyle(cargo_area, null).getPropertyValue('width');
                        var cargo_area_width_int = parseInt(cargo_area_width_string);
                        var cargo_area_right_int = cargo_area_left_int + cargo_area_width_int; //Marge dret de l'objecte (int)
                        var cargo_area_top_string = window.getComputedStyle(cargo_area, null).getPropertyValue('top');
                        var cargo_area_top_int = parseInt(cargo_area_top_string); //Marge superior de l'objecte (int)
                        var cargo_area_height_string = window.getComputedStyle(cargo_area, null).getPropertyValue('height');
                        var cargo_area_height_int = parseInt(cargo_area_height_string); 
                        var cargo_area_bottom_int = cargo_area_top_int + cargo_area_height_int;//Marge inferior de l'objecte (int)

                        if(key.keyCode == arrow_right){ //Colisio amb objecte "cargo_area" per la dreta
                                if (pj_left_int + pj_width_int + speed > cargo_area_left_int && pj_left_int < cargo_area_right_int && pj_top_int + pj_height_int > cargo_area_top_int && pj_top_int < cargo_area_bottom_int){
                                    ronda_entrega();
                                    cargo_area.style.display = "none";
                                    cargo_check = true;
                            }
                        }
                        if(key.keyCode == arrow_left){ //Colisio amb objecte "cargo_area" per l'esquerra
                                if (pj_left_int - speed < cargo_area_right_int && pj_left_int + pj_width_int > cargo_area_left_int && pj_top_int + pj_height_int > cargo_area_top_int && pj_top_int < cargo_area_bottom_int){
                                    ronda_entrega();
                                    cargo_area.style.display = "none";
                                    cargo_check = true;
                            }
                        }
                        if(key.keyCode == arrow_top){ //Colisio amb objecte "cargo_area" per sota
                                if (pj_top_int - speed < cargo_area_bottom_int && pj_left_int < cargo_area_right_int && pj_left_int + pj_width_int > cargo_area_left_int && pj_top_int + pj_height_int > cargo_area_top_int){
                                    ronda_entrega();
                                    cargo_area.style.display = "none";
                                    cargo_check = true;
                                }
                        }
                        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "cargo_area" per dalt
                                if (pj_top_int + pj_height_int + speed > cargo_area_top_int && pj_left_int < cargo_area_right_int && pj_left_int + pj_width_int > cargo_area_left_int && pj_top_int + pj_height_int < cargo_area_bottom_int){
                                    ronda_entrega();
                                    cargo_area.style.display = "none";
                                    cargo_check = true;
                                }
                        }
                }
                //Fi controlar entrada area carrega -----------------------------------------------

                //Controlar entrada a l'area d'entrega ----------------------------------------
                if (cargo_check == true){
                    var delivery_area_left_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('left');
                    var delivery_area_left_int = parseInt(delivery_area_left_string); //Marge esquerre de l'objecte (int)
                    var delivery_area_width_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('width');
                    var delivery_area_width_int = parseInt(delivery_area_width_string);
                    var delivery_area_right_int = delivery_area_left_int + delivery_area_width_int; //Marge dret de l'objecte (int)
                    var delivery_area_top_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('top');
                    var delivery_area_top_int = parseInt(delivery_area_top_string); //Marge superior de l'objecte (int)
                    var delivery_area_height_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('height');
                    var delivery_area_height_int = parseInt(delivery_area_height_string); 
                    var delivery_area_bottom_int = delivery_area_top_int + delivery_area_height_int;//Marge inferior de l'objecte (int)


                    if(key.keyCode == arrow_right){ //Colisio amb objecte "delivery_area_array[random_delivery]" per la dreta
                            if (pj_left_int + pj_width_int + speed > delivery_area_left_int && pj_left_int < delivery_area_right_int && pj_top_int + pj_height_int > delivery_area_top_int && pj_top_int < delivery_area_bottom_int){
                                score = score + score_up;
                                document.getElementById("score").innerHTML = score;
                                document.getElementById("final_score").innerHTML = score;
                                request_array[random_delivery].style.display = "none";
                                delivery_area_array[random_delivery].style.display ="none";
                                cargo_area.style.display = "block";
                                cargo_request.style.display = "none";
                                cargo_check = false;
                        }
                    }
                    if(key.keyCode == arrow_left){ //Colisio amb objecte "delivery_area_array[random_delivery]" per l'esquerra
                            if (pj_left_int - speed < delivery_area_right_int && pj_left_int + pj_width_int > delivery_area_left_int && pj_top_int + pj_height_int > delivery_area_top_int && pj_top_int < delivery_area_bottom_int){
                                score = score + score_up;  
                                document.getElementById("score").innerHTML = score;
                                document.getElementById("final_score").innerHTML = score;
                                request_array[random_delivery].style.display = "none";
                                delivery_area_array[random_delivery].style.display ="none";
                                cargo_area.style.display = "block";
                                cargo_request.style.display = "none";
                                cargo_check = false;
                        }
                    }
                    if(key.keyCode == arrow_top){ //Colisio amb objecte "delivery_area_array[random_delivery]" per sota
                            if (pj_top_int - speed < delivery_area_bottom_int && pj_left_int < delivery_area_right_int && pj_left_int + pj_width_int > delivery_area_left_int && pj_top_int + pj_height_int > delivery_area_top_int){
                                score = score + score_up;
                                document.getElementById("score").innerHTML = score;
                                document.getElementById("final_score").innerHTML = score;
                                request_array[random_delivery].style.display = "none";
                                delivery_area_array[random_delivery].style.display ="none";
                                cargo_area.style.display = "block";
                                cargo_request.style.display = "none";
                                cargo_check = false;
                            }
                    }
                    if(key.keyCode == arrow_bottom){ //Colisio amb objecte "delivery_area_array[random_delivery]" per dalt
                            if (pj_top_int + pj_height_int + speed > delivery_area_top_int && pj_left_int < delivery_area_right_int && pj_left_int + pj_width_int > delivery_area_left_int && pj_top_int + pj_height_int < delivery_area_bottom_int){
                                score = score + score_up;
                                document.getElementById("score").innerHTML = score;
                                document.getElementById("final_score").innerHTML = score;
                                request_array[random_delivery].style.display = "none";
                                delivery_area_array[random_delivery].style.display ="none";
                                cargo_area.style.display = "block";
                                cargo_request.style.display = "none";
                                cargo_check = false;
                            }
                    }
                }
                //Fi controlar entrada a l'area d'entrega-----------------------------------------------

                //Funció de control de colisio-------------------------------------------------------
                function colision(object){
                    var obj_colision = document.querySelectorAll(object);
                
                    obj_colision.forEach(function(object){ 
                        var obj_colision_left_string = window.getComputedStyle(object, null).getPropertyValue('left');
                        var obj_colision_left_int = parseInt(obj_colision_left_string); //Marge esquerre de l'objecte (int)
                        var obj_colision_width_string = window.getComputedStyle(object, null).getPropertyValue('width');
                        var obj_colision_width_int = parseInt(obj_colision_width_string);
                        var obj_colision_right_int = obj_colision_left_int + obj_colision_width_int; //Marge dret de l'objecte (int)
                        var obj_colision_top_string = window.getComputedStyle(object, null).getPropertyValue('top');
                        var obj_colision_top_int = parseInt(obj_colision_top_string); //Marge superior de l'objecte (int)
                        var obj_colision_height_string = window.getComputedStyle(object, null).getPropertyValue('height');
                        var obj_colision_height_int = parseInt(obj_colision_height_string); 
                        var obj_colision_bottom_int = obj_colision_top_int + obj_colision_height_int;//Marge inferior de l'objecte (int)


                        if(key.keyCode == arrow_right){ //Colisio amb objecte "object" per la dreta
                                if (pj_left_int + pj_width_int + speed > obj_colision_left_int && pj_left_int < obj_colision_right_int && pj_top_int + pj_height_int > obj_colision_top_int && pj_top_int < obj_colision_bottom_int){
                                    pj_left_int = obj_colision_left_int - pj_width_int;
                                    speedx = 0;
                            }
                        }
                        if(key.keyCode == arrow_left){ //Colisio amb objecte "object" per l'esquerra
                                if (pj_left_int - speed < obj_colision_right_int && pj_left_int + pj_width_int > obj_colision_left_int && pj_top_int + pj_height_int > obj_colision_top_int && pj_top_int < obj_colision_bottom_int){
                                    pj_left_int = obj_colision_right_int;
                                    speedx = 0;
                            }
                        }
                        if(key.keyCode == arrow_top){ //Colisio amb objecte "object" per sota
                                if (pj_top_int - speed < obj_colision_bottom_int && pj_left_int < obj_colision_right_int && pj_left_int + pj_width_int > obj_colision_left_int && pj_top_int + pj_height_int > obj_colision_top_int){
                                    pj_top_int = obj_colision_bottom_int;
                                    speedy = 0;
                                }
                        }
                        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "object" per dalt
                                if (pj_top_int + pj_height_int + speed > obj_colision_top_int && pj_left_int < obj_colision_right_int && pj_left_int + pj_width_int > obj_colision_left_int && pj_top_int + pj_height_int < obj_colision_bottom_int){
                                    pj_top_int = obj_colision_top_int - pj_height_int;
                                    speedy = 0;
                                }
                        }
                    }); 

                };
                //Fi funció de control de colisio-------------------------------------------------------

                //Controlar colisio amb obstacles --------------------------------------
                colision('.store');
                colision('.long_house');
                colision('.long_house2');
                colision('.corner_house');
                colision('.fountain');
                colision('.tree');
                colision('.truck');
                colision('.high_house');
                colision('.npc');
                
                //Fi controlar colisio amb obstacles --------------------------------------

                //Aplicar moviment
                pj_left_int = pj_left_int + speedx;
                pj_top_int = pj_top_int + speedy;

                //Conversió de num a string 
                pj.style.left = pj_left_int + "px";
                pj.style.top = pj_top_int + "px";
            }

        });

    }
}
